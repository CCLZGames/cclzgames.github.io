import tkinter as tk
import os, json, base64, sys

print("🚜 Starting Tiny Harvest...")

# ================= SAFE CONFIG =================
TILE_W, TILE_H = 96, 64
GRID_W, GRID_H = 10, 8
SAVE_FILE = "save.cclz"
CONFIG_FILE = "config.json"
KEY = "cclz_secret_key"

# ================= FIND ASSETS FOLDER =================
if os.path.isdir("assets"):
    ASSETS = "assets"
elif os.path.isdir("assests"):
    ASSETS = "assests"
else:
    print("❌ ERROR: No assets/assests folder found")
    sys.exit()

print(f"📁 Using asset folder: {ASSETS}")

# ================= LOAD CONFIG =================
def load_config():
    if not os.path.exists(CONFIG_FILE):
        print(⚠️ config.json missing — using defaults")
        return {"encrypted_save": True}

    try:
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    except Exception as e:
        print("❌ Config error:", e)
        return {"encrypted_save": True}

CONFIG = load_config()
print("⚙️ Config:", CONFIG)

# ================= ENCRYPTION =================
def encrypt(text):
    return base64.b64encode(
        ''.join(chr(ord(c) ^ ord(KEY[i % len(KEY)])) for i, c in enumerate(text)).encode()
    ).decode()

def decrypt(text):
    decoded = base64.b64decode(text).decode()
    return ''.join(chr(ord(c) ^ ord(KEY[i % len(KEY)])) for i, c in enumerate(decoded))

# ================= IMAGE LOADER =================
def load_image(root, filename, tw, th):
    path = os.path.join(ASSETS, filename)
    if not os.path.exists(path):
        print(f"❌ Missing image: {path}")
        sys.exit()

    img = tk.PhotoImage(file=path, master=root)
    w, h = img.width(), img.height()

    x = max(1, w // tw)
    y = max(1, h // th)

    print(f"🖼 {filename}: {w}x{h} -> tile {tw}x{th}")
    return img.subsample(x, y)

# ================= GAME =================
class FarmGame:
    def __init__(self, root):
        self.root = root
        root.title("Tiny Harvest")
        root.geometry("960x640")

        # -------- STATE --------
        self.day = 1
        self.money = 20
        self.inventory = {"seeds": 5}
        self.player_pos = [0, 0]
        self.grid = [[0]*GRID_W for _ in range(GRID_H)]

        # -------- CANVAS --------
        self.canvas = tk.Canvas(
            root,
            width=GRID_W * TILE_W,
            height=GRID_H * TILE_H,
            bg="#222"
        )
        self.canvas.pack()

        # -------- LOAD IMAGES --------
        self.soil = load_image(root, "soil.png", TILE_W, TILE_H)
        self.crops = {
            1: load_image(root, "crop1.png", TILE_W, TILE_H),
            2: load_image(root, "crop2.png", TILE_W, TILE_H),
            3: load_image(root, "crop3.png", TILE_W, TILE_H),
        }
        self.player = load_image(root, "player.png", TILE_W, TILE_H * 2)
        self.shop = load_image(root, "shop.png", TILE_W * 5, TILE_H * 3)

        # -------- UI --------
        self.info = tk.Label(root)
        self.info.pack()

        bar = tk.Frame(root)
        bar.pack()

        tk.Button(bar, text="Next Day", command=self.next_day).pack(side="left")
        tk.Button(bar, text="Inventory", command=self.inv).pack(side="left")
        tk.Button(bar, text="Shop", command=self.shop_ui).pack(side="left")
        tk.Button(bar, text="Save", command=self.save).pack(side="left")
        tk.Button(bar, text="Load", command=self.load).pack(side="left")

        root.bind("<Key>", self.move)
        self.draw()

    def draw(self):
        self.canvas.delete("all")
        for y in range(GRID_H):
            for x in range(GRID_W):
                px, py = x*TILE_W, y*TILE_H
                self.canvas.create_image(px, py, image=self.soil, anchor="nw")
                if self.grid[y][x]:
                    self.canvas.create_image(px, py, image=self.crops[self.grid[y][x]], anchor="nw")

        px, py = self.player_pos
        self.canvas.create_image(px*TILE_W, py*TILE_H-TILE_H, image=self.player, anchor="nw")

        self.info.config(
            text=f"Day {self.day} | $ {self.money} | Seeds {self.inventory['seeds']} | Encrypted {CONFIG['encrypted_save']}"
        )

    def move(self, e):
        dx = dy = 0
        if e.keysym in ("a", "Left"): dx = -1
        if e.keysym in ("d", "Right"): dx = 1
        if e.keysym in ("w", "Up"): dy = -1
        if e.keysym in ("s", "Down"): dy = 1
        if e.keysym == "space": self.interact()

        nx, ny = self.player_pos[0]+dx, self.player_pos[1]+dy
        if 0 <= nx < GRID_W and 0 <= ny < GRID_H:
            self.player_pos = [nx, ny]
        self.draw()

    def interact(self):
        x, y = self.player_pos
        if self.grid[y][x] == 0 and self.inventory["seeds"] > 0:
            self.grid[y][x] = 1
            self.inventory["seeds"] -= 1
        elif self.grid[y][x] == 3:
            self.grid[y][x] = 0
            self.money += 10
        self.draw()

    def next_day(self):
        self.day += 1
        for y in range(GRID_H):
            for x in range(GRID_W):
                if 1 <= self.grid[y][x] < 3:
                    self.grid[y][x] += 1
        self.draw()

    def inv(self):
        tk.messagebox.showinfo("Inventory", str(self.inventory))

    def shop_ui(self):
        win = tk.Toplevel(self.root)
        tk.Label(win, image=self.shop).pack()
        tk.Button(win, text="Buy Seed ($5)", command=self.buy).pack()

    def buy(self):
        if self.money >= 5:
            self.money -= 5
            self.inventory["seeds"] += 1
            self.draw()

    def save(self):
        data = json.dumps({
            "day": self.day,
            "money": self.money,
            "inv": self.inventory,
            "player": self.player_pos,
            "grid": self.grid
        })
        with open(SAVE_FILE, "w") as f:
            f.write(encrypt(data) if CONFIG["encrypted_save"] else data)
        print("💾 Saved")

    def load(self):
        if not os.path.exists(SAVE_FILE):
            return
        with open(SAVE_FILE) as f:
            content = f.read()
        if CONFIG["encrypted_save"]:
            content = decrypt(content)
        data = json.loads(content)
        self.day = data["day"]
        self.money = data["money"]
        self.inventory = data["inv"]
        self.player_pos = data["player"]
        self.grid = data["grid"]
        self.draw()

# ================= RUN =================
try:
    root = tk.Tk()
    FarmGame(root)
    root.mainloop()
except Exception as e:
    print("🔥 FATAL ERROR:", e)
